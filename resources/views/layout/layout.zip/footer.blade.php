<!-- Footer -->
<div class="navbar navbar-sm navbar-footer border-top px-lg-0">
    <div class="container-fluid container-boxed">
        <span>&copy; 2024 <a href="https://themeforest.net/item/limitless-responsive-web-application-kit/13080328">{{env('COMPANY_NAME')}} Web App Kit</a></span>
    </div>
</div>
<!-- /footer -->